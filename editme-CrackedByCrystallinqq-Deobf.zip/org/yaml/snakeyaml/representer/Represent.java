package org.yaml.snakeyaml.representer;

import org.yaml.snakeyaml.nodes.Node;

public interface Represent {
   Node representData(Object var1);
}
