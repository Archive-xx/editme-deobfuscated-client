package org.spongepowered.tools.obfuscation.interfaces;

public interface IOptionProvider {
   String getOption(String var1);
}
