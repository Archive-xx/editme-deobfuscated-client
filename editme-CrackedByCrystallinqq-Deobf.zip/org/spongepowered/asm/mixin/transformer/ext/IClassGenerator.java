package org.spongepowered.asm.mixin.transformer.ext;

public interface IClassGenerator {
   byte[] generate(String var1);
}
