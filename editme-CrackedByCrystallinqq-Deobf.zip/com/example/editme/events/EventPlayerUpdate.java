package com.example.editme.events;

public class EventPlayerUpdate extends EditmeEvent {
}
