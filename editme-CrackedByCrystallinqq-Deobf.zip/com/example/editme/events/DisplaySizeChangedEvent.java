package com.example.editme.events;

public class DisplaySizeChangedEvent {
}
