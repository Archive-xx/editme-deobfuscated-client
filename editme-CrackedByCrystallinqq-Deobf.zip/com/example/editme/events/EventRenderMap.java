package com.example.editme.events;

public class EventRenderMap extends EditmeEvent {
}
