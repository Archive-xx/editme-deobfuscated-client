package com.example.editme.events;

public class EventClientTick extends EditmeEvent {
}
