package me.zero.alpine.listener;

@FunctionalInterface
public interface EventHook {
   void invoke(Object var1);
}
