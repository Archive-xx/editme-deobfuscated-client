package me.zero.alpine.type;

public enum EventState {
   PRE,
   POST;

   private static final EventState[] $VALUES = new EventState[]{PRE, POST};
}
