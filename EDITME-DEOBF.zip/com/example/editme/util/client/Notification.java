package com.example.editme.util.client;

public class Notification {
   public String content;
   public String header;

   public Notification(String var1, String var2) {
      this.header = var1;
      this.content = var2;
   }
}
