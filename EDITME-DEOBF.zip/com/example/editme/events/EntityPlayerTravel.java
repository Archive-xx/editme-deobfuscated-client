package com.example.editme.events;

public class EntityPlayerTravel extends EditmeEvent {
}
