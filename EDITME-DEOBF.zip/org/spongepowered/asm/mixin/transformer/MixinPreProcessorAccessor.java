package org.spongepowered.asm.mixin.transformer;

class MixinPreProcessorAccessor extends MixinPreProcessorInterface {
   public MixinPreProcessorAccessor(MixinInfo var1, MixinInfo.MixinClassNode var2) {
      super(var1, var2);
   }
}
