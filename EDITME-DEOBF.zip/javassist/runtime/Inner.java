package javassist.runtime;

public class Inner {
}
